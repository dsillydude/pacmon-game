import PacmonGameTest from '@/components/PacmonGameTest'

export default function TestPage() {
  return <PacmonGameTest />
}

