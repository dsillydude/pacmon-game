import PacmonGameTestDemo from '@/components/PacmonGameTestDemo'

export default function DemoPage() {
  return <PacmonGameTestDemo />
}

